<?php if(!class_exists('Rain\Tpl')){exit;}?>  
</section>
<footer class="ui-widget-header">
    <p>Desenvolvido por</p>
    <p>Rodolfo Paolucci <a href="https://www.twitch.tv/rodsrufo/" target="blank">twitch.tv/rodsrufo</a></p>
    <p>Yure's <a href="https://github.com/jon-by" target="blank">github.com/jon-by</a></p>
</footer>

<script src="/assets/js/main.js"></script>
</body>
</html>