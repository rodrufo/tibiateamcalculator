<?php if(!class_exists('Rain\Tpl')){exit;}?>  
  


<script src="/assets/js/main.js"></script>
</body>
</html>