<?php

$app->get('/partyhuntanalyser', function () {
    echo "retorna view da página de party hunt analyser";
});
